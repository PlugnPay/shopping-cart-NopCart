=================================================
Plug 'n Pay - Smart Screens Method
Payment Module for NopCart v4.4.0
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the NOP shopping cart community at
'http://www.nopdesign.com/freecart/', and if you are still unable to resolve the issue,
contact us via PlugnPay's Online Helpdesk.

This module is used without having your own server's SSL abilities. We will ask the
customer for all of their credit card info on our SSL secured billing pages on our
secured servers.  The authorization will be done via PlugnPay's Smart Screens payment
method.  This module will itemize the order in the PlugnPay system using available
information from the cart.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized NOP shopping cart modules will not be provided
support assistance.
***************************

Requirements:

  You need to be running some version of NopCart v4.4.0 or newer.

  At the time of this write-up, this module seems to work without incident
under NopCart v4.4.0.  Your millage may vary with newer builds of this cart.


Installation:

  Download & install the NOP shopping cart to your site normally.
  (See 'http://www.nopdesign.com/freecart/' for how to setup this shopping cart solution)

  Update the supplied 'nopcart.js' file's settings to use your PnP account.

  When editing the 'nopcart.js' file, you should ONLY need to update the:
    ==> "Options for Everyone" section
      and
    ==> some parts within the "PnP Gateway Settings/Options" section

  You should NOT need to modify anything within the "Options for Programmers" section.
    As this section is already pre-configured for PnP usage.

  Upload the modified 'nopcart.js' file to where you installed the NOP shopping cart.
    (Overwriting the existing 'nopcart.js' file, with the one you are uploading.)

  Refer to the comments contained within 'nopcart.js' file, for how to finalize the setup.
    For basic setups, you need only apply the sample HTML form code to your cart's checkout page.


Troubleshooting:

  Check to be sure you uploaded the files into their correct folders.

  Check to be sure you overwrote the existing 'nopcart.js' file, when you uploaded our version. 

  Check the uploaded file's permission:
  -- the 'nopcart.js' file should be chmod 644
     (read/write by owner, read only by all others)

  These are the common issues found by our support staff.

